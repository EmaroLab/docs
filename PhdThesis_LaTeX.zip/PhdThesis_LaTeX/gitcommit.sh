git add .
git commit -am "autosave %date%-%time:~0,8% (from TexStudio)"
